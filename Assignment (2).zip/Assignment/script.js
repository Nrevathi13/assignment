document.getElementById('add-to-cart').addEventListener('click', function() {
    const color = document.getElementById('color-selector').value;
    const size = document.getElementById('size-selector').value;
    const quantity = document.getElementById('quantity-selector').value;

    document.getElementById('cart-message').innerText = `Added ${quantity} item(s) of size ${size} in color ${color} to cart.`;
    document.getElementById('cart-message').style.display = 'block';
});